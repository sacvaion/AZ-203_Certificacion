﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Negocio
{
    public class Book
    {
        public int BookId { get; set; }
        public string Url { get; set; }
        public string Description { get; set; }

    }
}
